#!/bin/sh
sshfs username@nas:/share /home/username/nas
