#!/bin/sh
sudo date >> /var/log/vpn-gateway.log;
sudo echo -n "Removing FIREWALL RULES FOR NAT. " | tee -a /var/log/vpn-gateway.log
sudo iptables -F INPUT 
sudo iptables -P INPUT ACCEPT
sudo iptables -F OUTPUT
sudo iptables -P OUTPUT ACCEPT
sudo iptables -F FORWARD
sudo iptables -P FORWARD ACCEPT
sudo iptables -t nat -F
sudo echo "NordVPN GATEWAY IS DISCONNECTED." >> /var/log/vpn-gateway.log
