import gi
gi.require_version("Gtk", "4.0")  # or "4.0" for GTK 4
from gi.repository import Gtk

# Print GTK version
print(f"GTK version: {Gtk.get_major_version()}.{Gtk.get_minor_version()}.{Gtk.get_micro_version()}")
