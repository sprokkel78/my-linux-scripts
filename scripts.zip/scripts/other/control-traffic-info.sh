#!/bin/sh
cat /etc/iproute2/rt_tables

ip r list table all | grep _table

ip rule list 

# Show the iptables mangle table
echo "=================="
echo "IPTABLES -t MANGLE"
echo "=================="
sudo iptables -t mangle -L OUTPUT -vn

# Show the iptables nat table
echo "==============="
echo "IPTABLES -t NAT"
echo "==============="
sudo iptables -t nat -L POSTROUTING -vn

# Show the routing table
echo "============="
echo "IP ROUTE LIST"
echo "============="
ip r

#EOF

