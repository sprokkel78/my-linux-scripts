#!/bin/sh
sudo nmcli c down id Telenet-2423S88
sudo nmcli radio wifi on
sudo rfkill block wifi
nordvpn d
