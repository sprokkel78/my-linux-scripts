#!/bin/sh
sudo rfkill unblock wifi
sudo nmcli radio wifi on
sudo nmcli c up id telenet-2423S88 --ask
#nordvpn c be
