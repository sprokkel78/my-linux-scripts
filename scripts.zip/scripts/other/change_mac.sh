#!/bin/bash

# Generate a random MAC address
new_mac=$(openssl rand -hex 6 | sed 's/\(..\)/\1:/g; s/.$//')

# Disable the network interface
ifconfig end0 down

# Change the MAC address
ifconfig end0 hw ether $new_mac

# Enable the network interface
ifconfig end0 up

echo "MAC address for end0 changed to $new_mac"

# Generate a random MAC address
new_mac=$(openssl rand -hex 6 | sed 's/\(..\)/\1:/g; s/.$//')

# Disable the network interface
ifconfig wlp1s0f0 down

# Change the MAC address
ifconfig wlp1s0f0 hw ether $new_mac

# Enable the network interface
ifconfig wlp1s0f0 up

echo "MAC address for wlp1s0f0 changed to $new_mac"
