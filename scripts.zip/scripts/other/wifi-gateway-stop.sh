#!/bin/sh
sudo iptables -t nat -D POSTROUTING -s 192.168.1.0/24 -o wlp1s0f0 -j MASQUERADE
sudo iptables -t nat -L -vn
