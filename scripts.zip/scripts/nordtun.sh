iftop -i nordtun -m 30M
