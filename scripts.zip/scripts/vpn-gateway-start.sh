#!/bin/sh
sudo date >> /var/log/vpn-gateway.log;
sudo echo -n "Adding FIREWALL RULES FOR NAT. " | tee -a /var/log/vpn-gateway.log
sleep 3

# INPUT POLICY = DROP.
sudo iptables -P INPUT DROP
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -I INPUT -p tcp --dport 80  -m conntrack --ctstate NEW -j ACCEPT # ALLOW HTTP TRAFFIC

# ENABLE CONNECTION TRACKING: INCOMING IS ONLY ALLOWED WHEN THERE'S FIRST OUTGOING TRAFFIC.
iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# DISABLE NTP ACCESS
sudo iptables -I OUTPUT -p tcp --dport 123 -j DROP

# ALLOW LAN THROUGH FORWARD ZONE.
sudo iptables -P FORWARD DROP
sudo iptables -I FORWARD -s 192.168.1.0/24 -j ACCEPT -m comment --comment "sprokkel FORWARD LAN TRAFFIC"
sudo iptables -I FORWARD -d 192.168.1.0/24 -j ACCEPT -m comment --comment "sprokkel FORWARD LAN TRAFFIC"
sudo iptables -I FORWARD -s 192.168.1.101 -j DROP  -m comment --comment "sprokkel DROP TRAFFIC FOR LGTV"
#sudo iptables -I FORWARD -s 192.168.1.200 -j DROP -m comment --comment "sprokkel DROP TRAFFIC FOR REPEATER"

# ALLOW CLIENTS THROUGH THE GATEWAY.
#sudo iptables -t nat -I POSTROUTING -s 192.168.1.0/24 -o nordtun -j MASQUERADE #(WHOLE LAN)
#sudo iptables -t nat -I POSTROUTING -s 192.168.1.101 -o nordtun -j MASQUERADE #(LGTV)
sudo iptables -t nat -I POSTROUTING -s 192.168.1.102 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.103 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.104 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.105 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.106 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.112 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.113 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.150 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.151 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.152 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.153 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.154 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.155 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.156 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.157 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.158 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.159 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.160 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.161 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.162 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.163 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.164 -o nordtun -j MASQUERADE
sudo iptables -t nat -I POSTROUTING -s 192.168.1.165 -o nordtun -j MASQUERADE

# PORT TRIGGERING DROPPINGS
sudo iptables -I INPUT -p tcp --dport 500 -m recent --name bad_ip --set
sudo iptables -I INPUT -m recent --name bad_ip --rcheck --seconds 300 --hitcount 1 -j DROP

sudo echo "NordVPN GATEWAY IS ACTIVE." >> /var/log/vpn-gateway.log

