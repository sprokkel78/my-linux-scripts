sudo find / -type f -size +500M 2>/dev/null

